python eval_DIRECT.py -evalitem all -fn test_eqg_eval.json
