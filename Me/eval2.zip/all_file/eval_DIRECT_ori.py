#Merged and edited by Jin-Xia Huang, ETRI, hgh@etri.re.kr, 2021
#Following code are partially from: 
#   alexa_dstc9-1 baseline code, https://github.com/alexa/alexa-with-dstc9-track1-dataset/tree/master/baseline 
#                               (./baseline/scripts/scores.py, /baseline/utils/metrics.py, /baseline/utils/data.py)
#   UBAR source code, https://github.com/TonyNemo/UBAR-MultiWOZ 
#   N-gram diversity: https://github.com/alexa/Topical-Chat

#from ./baseline/scripts/scores.py
from nltk.translate.bleu_score import sentence_bleu, corpus_bleu, SmoothingFunction
from nltk.translate.meteor_score import single_meteor_score
from rouge import Rouge 

#from ./baseline/utils/metrics.py
import numpy as np
from nltk import bigrams as get_bigrams
from nltk import trigrams as get_trigrams
from nltk import word_tokenize, ngrams
from collections import Counter

import os
import re
import sys
import json
import argparse

#from UBAR
import math

# folder: ./baseline/scripts/scores.py
# usage: python scripts/check_results.py --dataset val --dataroot data/ --outfile baseline_val.json
# usage: python scripts/scores.py --dataset val --dataroot data/ --outfile baseline_val.json --scorefile baseline_val.score.json

# python scripts/check_results.py --dataset val --dataroot data4test/ --outfile pred/val/test.end2end.ks2rg.json
# python scripts/scores.py --dataset val --dataroot data4test/ --outfile pred/val/test.end2end.ks2rg.json --scorefile pred/val/test.end2end.ks2rg.score.json

# from dualWGan measure.py 
from sklearn.metrics.pairwise import cosine_similarity as cosine
from sklearn.metrics import f1_score
import copy


RE_ART = re.compile(r'\b(a|an|the)\b')
RE_PUNC = re.compile(r'[!"#$%&()*+,-./:;<=>?@\[\]\\^`{|}~_\']')


def remove_articles(_text):
    return RE_ART.sub(' ', _text)


def white_space_fix(_text):
    return ' '.join(_text.split())


def remove_punc(_text):
    return RE_PUNC.sub(' ', _text)  # convert punctuation to spaces


def lower(_text):
    return _text.lower()


def normalize(text):
    """Lower text and remove punctuation, articles and extra whitespace. """
    #return white_space_fix(remove_articles(remove_punc(lower(text))))
    return white_space_fix(remove_punc(lower(text)))
    #return white_space_fix(lower(text))

def get_fourgrams(sequence, **kwargs):
    """
    Return the 4-grams generated from a sequence of items, as an iterator.

    :param sequence: the source data to be converted into 4-grams
    :type sequence: sequence or iter
    :rtype: iter(tuple)
    """

    for item in ngrams(sequence, 4, **kwargs):
        yield item


#fro UBAR eval.py
class BLEUScorer(object):
    ## BLEU score calculator via GentScorer interface
    ## it calculates the BLEU-4 by taking the entire corpus in
    ## Calulate based multiple candidates against multiple references
    def __init__(self):
        pass

    def score(self, parallel_corpus):   #ubar type

        # containers
        count = [0, 0, 0, 0]
        clip_count = [0, 0, 0, 0]
        r = 0
        c = 0
        weights = [0.25, 0.25, 0.25, 0.25]

        # accumulate ngram statistics
        for hyps, refs in parallel_corpus:
            hyps = [hyp.split() for hyp in hyps]
            refs = [ref.split() for ref in refs]
            for hyp in hyps:

                for i in range(4):
                    # accumulate ngram counts
                    hypcnts = Counter(ngrams(hyp, i + 1))
                    cnt = sum(hypcnts.values())
                    count[i] += cnt

                    # compute clipped counts
                    max_counts = {}
                    for ref in refs:
                        refcnts = Counter(ngrams(ref, i + 1))
                        for ng in hypcnts:
                            max_counts[ng] = max(max_counts.get(ng, 0), refcnts[ng])
                    clipcnt = dict((ng, min(count, max_counts[ng])) \
                                   for ng, count in hypcnts.items())
                    clip_count[i] += sum(clipcnt.values())

                # accumulate r & c
                bestmatch = [1000, 1000]
                for ref in refs:
                    if bestmatch[0] == 0: break
                    diff = abs(len(ref) - len(hyp))
                    if diff < bestmatch[0]:
                        bestmatch[0] = diff
                        bestmatch[1] = len(ref)
                r += bestmatch[1]
                c += len(hyp)

        # computing bleu score
        p0 = 1e-7
        bp = 1 if c > r else math.exp(1 - float(r) / float(c))
        p_ns = [float(clip_count[i]) / float(count[i] + p0) + p0 \
                for i in range(4)]
        s = math.fsum(w * math.log(p_n) \
                      for w, p_n in zip(weights, p_ns) if p_n)
        bleu = bp * math.exp(s)
        return bleu 
    


class DIRECTEval():
    def __init__(self):
        self.bleu_scorer = BLEUScorer()

    def bleu_metric(self, data, eval_dial_list=None):
        gen, truth = [],[]
        #lgen, ltruth = [],[]
        #print('hghdebug eval.py bleu_metric()\n')
        pair_num = 0
        sent_bleu_sum = 0
        for row in data:        #hyps, refs, info            
            if row[1] == '' :
                continue
            if eval_dial_list and row['dial_id'] +'.json' not in eval_dial_list:
                continue
            gen.append( normalize(row[0]) )
            truth.append( normalize(row[1]) )
            '''
            lgen.append(row[0].split())
            ltruth.append(row[1].split())
            '''
            sent_bleu_sum += sentence_bleu([ normalize(row[1]).split() ], normalize(row[0]).split(), weights=[0.25,0.25,0.25,0.25])
            pair_num += 1
            #print('\t target:{}\n\t resp_gen:{}'.format(row[1], row[0]))
        wrap_generated = [[_] for _ in gen]
        wrap_truth = [[_] for _ in truth]
        #cor_bleu = corpus_bleu(ltruth, lgen)
        if gen and truth:            
            sc = self.bleu_scorer.score(zip(wrap_generated, wrap_truth))            
        else:
            sc = 0.0

        
        sent_bleu = 0.0
        if pair_num > 0:
            sent_bleu = sent_bleu_sum / pair_num         
        return (sc, sent_bleu)

    def acc_metrics(self, data, eval_dial_list=None):
        bspn_acc = 0
        aspn_acc = 0
        gspn_exact = 0
        gspn_fuzzy = 0        
        rightbspn = 0 
        rightaspn = 0 
        exactgspn = 0
        fuzzygspn = 0

        pair_num = 0
        gspn_num = 0
        for row in data:        #hyps, refs, info=[(bspn_gen, bspn), (aspn_gen, aspn), (gspn_gen, gspn)]
            if row[1] == '' :
                continue
            
            if row[2] == None or type(row[2]) != type([]):
                return (bspn_acc, aspn_acc, pair_num, gspn_exact, gspn_fuzzy, gspn_num)
            
            pair_num += 1 
            
            for idx, (gen, ref) in enumerate(row[2]):
                if idx == 0:
                    if gen == 'label init': 
                        gen = 'label none'
                    if ref == 'label init':
                        ref = 'label none'
                    if (gen == 'label correct' and ref == 'label correct') or gen.find(ref) >= 0: #gen: pretype qa label correct , ref: label correct
                        rightbspn += 1
                    elif (gen == 'label none' and ref == 'label none') or gen.find(ref) >= 0: #gen: pretype qa label correct , ref: label correct
                        rightbspn += 1
                    else:
                        #print('hgh bspn error: gen:{}, ref:{}, idx:{}, row[2]:{}'.format(gen, ref, idx, row[2]))
                        #input('press enter')
                        pass
                elif idx ==1:
                    if gen == ref or (gen=='type topic' and ref =='type bye'):
                        rightaspn += 1
                    else:
                        #print('hgh aspn error: gen:{}, ref:{}, idx:{}, row[2]:{}'.format(gen, ref, idx, row[2]))
                        #input('press enter')
                        pass
                        
                else:   #gspn
                    iposi1 = ref.find('<sos_s> ')
                    iposi2 = ref.find(' <eos_s>')
                    if iposi1>=0 and iposi2 > 0: 
                        ref = ref[iposi1+7 :iposi2]
                    elif iposi1>=0: 
                        ref = ref[iposi1+7:]
                    else:
                        continue
                    ref = normalize(ref)
                   
                    gspn_num += 1
                    iposi1 = gen.find('<sos_s> ') 
                    iposi2 = gen.find(' <eos_s>')                    
                    
                    
                    if iposi1>=0 and iposi2 > 0: 
                        gen = gen[iposi1+7 :iposi2]
                    elif iposi1>=0: 
                        gen = gen[iposi1+7:]
                    else:
                        continue
                    gen = normalize(gen)
                    
                    
                    if gen == ref:
                        exactgspn += 1
                    elif gen.find(ref)>=0 or ref.find(gen) >=0:
                        fuzzygspn += 1
                    else:
                        pass
                        #print('hgh gspn error: gen:{}, ref:{}'.format(gen, ref))
                        #input('press enter')
                
        
        bspn_acc = 0
        aspn_acc = 0
        if pair_num > 0:
            bspn_acc = rightbspn*1.0 / pair_num
            aspn_acc = rightaspn*1.0 / pair_num      
            print('Evaluation result: \n\tturn_num:{}, \n\tuser_label_acc:{}%'.format(pair_num, int(bspn_acc*10000)/100))

        if gspn_num > 0   :
            gspn_exact = exactgspn*1.0 / gspn_num
            gspn_fuzzy = (exactgspn + fuzzygspn)*1.0 / gspn_num
        #print('rightbspn:{}, rightaspn:{}, pair_num:{}, exactgspn:{}, gspn_exact_rate:{}, fuzzygspn:{}, {}, gspn_num:{}'.format(bspn_acc, aspn_acc, pair_num, exactgspn, gspn_exact, gspn_fuzzy, fuzzygspn, gspn_num))
        #input('bagg2')
        return (bspn_acc, aspn_acc, pair_num, gspn_exact, gspn_fuzzy, gspn_num)

class Metric:
    def __init__(self):
        self.reset()
    
    def reset(self):
        pass
    
    def update(self, output):
        raise NotImplementedError()
    
    def compute(self):
        raise NotImplementedError()



class UnigramMetric(Metric):    #normalize()
    def __init__(self, metric):
        self._score = None
        self._count = None
        if metric.lower() not in ["recall", "precision"]:
            raise ValueError("mertic should be either 'recall' or 'precision', got %s" % metric)
        self.metric = metric.lower()
        super(UnigramMetric, self).__init__()

    def reset(self):
        self._score = 0
        self._count = 0
        super(UnigramMetric, self).reset()

    def update(self, output):
        # hypothesis and reference are assumed to be actual sequences of tokens
        hypothesis, reference = output

        hyp_tokens = normalize(hypothesis).split()
        ref_tokens = normalize(reference).split()

        common = Counter(ref_tokens) & Counter(hyp_tokens)
        num_same = sum(common.values())

        if num_same == 0:
            score = 0
        else:
            if self.metric == "precision":
                score = 1.0 * num_same / len(hyp_tokens)
            else:
                assert self.metric == "recall"
                score = 1.0 * num_same / len(ref_tokens)

        self._score += score
        self._count += 1

    def compute(self):
        if self._count == 0:
            raise ValueError("Unigram metrics must have at least one example before it can be computed!")
        return self._score / self._count
    
    def name(self):
        return "Unigram{:s}".format(self.metric.capitalize())


class NGramDiversity(Metric):
    def __init__(self, n=1):
        self._n = n
        self._diversity = None
        self._count = None

        if self._n not in [1, 2, 3, 4]:
            raise ValueError("NGramDiversity only supports n=1 (unigrams), n=2 (bigrams),"
                             "n=3 (trigrams) and n=4 (4-grams)!")

        self.ngram_func = {
            1: lambda x: x,
            2: get_bigrams,
            3: get_trigrams,
            4: get_fourgrams
        }[self._n]

        super(NGramDiversity, self).__init__()

    def reset(self):
        self._diversity = 0
        self._count = 0
        super(NGramDiversity, self).reset()

    def update(self, output):
        hypothesis, _ = output

        if hypothesis is None:
            diversity = 0
        else:
            diversity = 0
            output_tokens = word_tokenize(hypothesis)
            denominator = float(len(output_tokens))

            if denominator != 0.0:
                ngrams = set(list(self.ngram_func(output_tokens)))
                diversity = len(ngrams) / denominator

        self._diversity += diversity
        self._count += 1

    def compute(self):
        if self._count == 0:
            raise ValueError("NGramDiversity must consume at least one example before it can be computed!")
        return self._diversity / self._count

    def name(self):
        return "{:d}GramDiversity".format(self._n)


class CorpusNGramDiversity(Metric):
    def __init__(self, n=1):
        self._n = n

        self._ngrams = None
        self._token_count = None

        if self._n not in [1, 2, 3, 4]:
            raise ValueError("CorpusNGramDiversity only supports n=1 (unigrams), n=2 (bigrams),"
                             "n=3 (trigrams) and n=4 (4-grams)!")
        self.ngram_func = {
            1: lambda x: x,
            2: get_bigrams,
            3: get_trigrams,
            4: get_fourgrams
        }[self._n]

        super(CorpusNGramDiversity, self).__init__()

    def reset(self):
        self._ngrams = set()
        self._token_count = 0
        super(CorpusNGramDiversity, self).reset()

    def update(self, output):
        hypothesis, _ = output
        if isinstance(hypothesis, str) and hypothesis:
            output_tokens = word_tokenize(hypothesis)

            ngrams = list(self.ngram_func(output_tokens))
            self._ngrams.update(ngrams)
            self._token_count += len(output_tokens)

    def compute(self):
        if self._token_count == 0:
            raise ValueError("CorpusNGramDiversity must consume at least one example before it can be computed!")

        return len(self._ngrams) / self._token_count
    
    def name(self):
        return "Corpus{:d}GramDiversity".format(self._n)



class EmbeddingMetric(Metric):  #no normalize
    def __init__(self, dataroot):
        self.vec_size = 200
        self.word_emb_file = os.path.join(dataroot, "data/dict/word_emb.json")            
        self.word2idx_file = os.path.join(dataroot, "data/dict/word2idx.json")
        self.idx2word_file = os.path.join(dataroot, "data/dict/idx2word.json")
        
        self._generation_embed_greedy = None
        self._generation_embed_average = None
        self._generation_embed_extrema = None
        self._intra_dist1 = None
        self._intra_dist2 = None
        self._inter_dist1 = None
        self._inter_dist2 = None
        self._count = None
        self._f1 = None                  
        self._precision = None
        self._recall = None


        flags ={
            'word_emb_file': self.word_emb_file,
            'word2idx_file': self.word2idx_file,
            'idx2word_file': self.idx2word_file,
        }

        with open(flags['word_emb_file'], "r") as fp:            
            self.word_mat = np.array(json.load(fp), dtype=np.float32)
        with open(flags['word2idx_file'], "r") as fp:            
            self.word2idx = json.load(fp)
        with open(flags['idx2word_file'], "r") as fp:
            self.idx2word = json.load(fp)
        
        self.embedding_dict = self.__init_word_embedding_vocab()
        super(EmbeddingMetric, self).__init__()
    
    def __init_word_embedding_vocab(self):
        embedding_dict = {}
        for k,v in self.word2idx.items():
            embedding_dict[k] = self.word_mat[v]
        return embedding_dict

    def __cosine_similarity(self, vec1, vec2):
        return cosine([vec1], [vec2])[0][0]

    def __extrema_vector(self, v1):
        max_vector = np.max(v1, axis=0)
        min_vector = np.min(v1, axis=0)
        abs_min_vector = np.abs(min_vector)

        extrema_vector = []
        for i, vec in enumerate(max_vector):
            if vec > abs_min_vector[i]:
                extrema_vector.append(vec)
            else:
                extrema_vector.append(min_vector[i])
        return extrema_vector

    def reset(self):
        self._generation_embed_greedy = 0.0
        self._generation_embed_average = 0.0
        self._generation_embed_extrema = 0.0
        
        self._f1 = 0.0        
        self._precision = 0.0
        self._recall = 0.0

        self._intra_dist1 = 0.0
        self._intra_dist2 = 0.0
        self._inter_dist1 = 0.0
        self._inter_dist2 = 0.0
        self._count = 0
        

        super(EmbeddingMetric, self).reset()
    
    def get_vectors(self, str):
        vectors = []
        
        for word in str.strip().split():
            if word not in self.embedding_dict:
                vectors.append(self.embedding_dict['--UNK--'])
            else:
                vectors.append(self.embedding_dict[word])
        return vectors

    def get_dist_score(self, predict):
        unigram_tokens = predict.split()
        intra_dist1 = (len(set(unigram_tokens))+1e-12)/(len(unigram_tokens)+1e-12)

        bigram_tokens = [(unigram_tokens[k], unigram_tokens[k+1]) for k in range(len(unigram_tokens)-1)]
        intra_dist2 = (len(set(bigram_tokens))+1e-12)/(len(bigram_tokens)+1e-12)
        return intra_dist1, intra_dist2
    
    def get_inter_dist_socre(self, predicts):
        total_words = ''
        for pred in predicts:
            total_words = total_words + ' '+pred

        unigram_total_words = total_words.replace('  ',' ').strip().split()
        bigram_total_words = [(unigram_total_words[k], unigram_total_words[k+1]) for k in range(len(unigram_total_words)-1)]

        dist1 = (len(set(unigram_total_words)) + 1e-12) / (len(unigram_total_words) + 1e-12)

        bigram_tokens = [(unigram_total_words[k], unigram_total_words[k + 1]) for k in range(len(unigram_total_words) - 1)]
        dist2 = (len(set(bigram_tokens)) + 1e-12) / (len(bigram_total_words) + 1e-5)

        return dist1, dist2
    
    def get_uni_gram_f1(self, answer, predict):
        ref = answer.split()
        pred = predict.split()

        _ref = copy.deepcopy(ref)
        p, n = 0, 0
        for token in pred:
            if token in _ref:
                _ref.remove(token)
                p += 1
            else:
                n += 1
        if p == 0 and n == 0:
            precision = 0
        else:
            precision = p / (p + n)

        p, n = 0, 0
        _pred = copy.deepcopy(pred)
        for token in ref:
            if token in _pred:
                _pred.remove(token)
                p += 1
            else:
                n += 1
        if p == 0 and n == 0:
            recall = 0
        else:
            recall = p / (p + n)
        f1 = 2 * precision * recall / (precision + recall + 1e-10)
        return (f1, precision, recall)

    def update(self, output):
        predict, answer  = output        
        predict = normalize(predict)
        answer = normalize(answer)

        predict_vectors = self.get_vectors(predict)
        answer_vectors = self.get_vectors(answer)        

        if not predict:
            return  0,0,0

        cos_sim = cosine(predict_vectors, answer_vectors).reshape((1, len(predict_vectors), 1, len(answer_vectors)))
        max12 = cos_sim.max(1).mean(2)
        max21 = cos_sim.max(3).mean(1)
        greedy_score= (max12 + max21) / 2
        if greedy_score[0][0] > 0:
            self._generation_embed_greedy += greedy_score[0][0]

        answer_avg_vector = np.mean(answer_vectors, axis=0)
        predict_avg_vectors = np.mean(predict_vectors, axis=0)
        ave_score = cosine([predict_avg_vectors], [answer_avg_vector])[0][0]
        if  ave_score > 0:
            self._generation_embed_average += ave_score

        answer_extrema_vector = self.__extrema_vector(answer_vectors)
        predict_extrema_vector = self.__extrema_vector(predict_vectors)
        extrema_score = self.__cosine_similarity(answer_extrema_vector, predict_extrema_vector)
        if extrema_score > 0: 
            self._generation_embed_extrema += extrema_score
        
        (f1, precision, recall) = self.get_uni_gram_f1(answer, predict) 

        self._f1 += f1
        self._precision += precision
        self._recall += recall
        intra_dist1, intra_dist2 = self.get_dist_score(predict)
        inter_dist1, inter_dist2 = self.get_inter_dist_socre(predict)
        self._intra_dist1 += intra_dist1
        self._intra_dist2 += intra_dist2
        self._inter_dist1 += inter_dist1
        self._inter_dist2 += inter_dist2
        self._count += 1
        

        
    def name(self):
        return "EmbeddingMetric"
    
    def compute(self):
        if self._count == 0:
            raise ValueError("EmbeddingMetric must consume at least one example before it can be computed!")
        
        embed_greedy = self._generation_embed_greedy / self._count
        embed_average = self._generation_embed_average / self._count
        embed_extrema = self._generation_embed_extrema / self._count
        
        intra_dist1 = self._intra_dist1 / self._count
        intra_dist2 = self._intra_dist2 / self._count
        inter_dist1 = self._inter_dist1 / self._count
        inter_dist2 = self._inter_dist2 / self._count

        f1 = self._f1 / self._count
        precision = self._precision / self._count
        recall = self._recall / self._count

        scores = { 
            'f1': f1,
            'precision': precision,
            'recall': recall,
            'embed_greedy': embed_greedy,
            'embed_average': embed_average,
            'embed_extrema': embed_extrema,
            'intra_dist1': intra_dist1, 
            'intra_dist2': intra_dist2,
            'inter_dist1': inter_dist1, 
            'inter_dist2': inter_dist2
        }

        return scores


class PairwiseMetric(Metric):   #_normalize_text, RE_PUNC, RE_ART
    def __init__(self):
        self.reset()

    def reset(self):
        self._detection_tp = 0.0
        self._detection_fp = 0.0
        self._detection_tn = 0.0
        self._detection_fn = 0.0
        
        self._selection_mrr5 = 0.0
        self._selection_r1 = 0.0
        self._selection_r5 = 0.0

        self._generation_bleu = 0.0
        self._generation_bleu1 = 0.0
        self._generation_bleu2 = 0.0
        self._generation_bleu3 = 0.0
        self._generation_bleu4 = 0.0
        
        self._generation_meteor = 0.0
        self._generation_rouge_1 = 0.0
        self._generation_rouge_2 = 0.0
        self._generation_rouge_l = 0.0


    def _match(self, ref_knowledge, pred_knowledge):
        result = []
        for pred in pred_knowledge:
            matched = False
            for ref in ref_knowledge:
                if pred['domain'] == ref['domain'] and pred['entity_id'] == ref['entity_id'] and pred['doc_id'] == ref['doc_id']:
                    matched = True
            result.append(matched)
        return result
        
    def _reciprocal_rank(self, ref_knowledge, hyp_knowledge, k=5):
        relevance = self._match(ref_knowledge, hyp_knowledge)[:k]

        if True in relevance:
            idx = relevance.index(True)
            result = 1.0/(idx+1)
        else:
            result = 0.0

        return result

    def _recall_at_k(self, ref_knowledge, hyp_knowledge, k=5):
        relevance = self._match(ref_knowledge, hyp_knowledge)[:k]

        if True in relevance:
            result = 1.0
        else:
            result = 0.0

        return result

    def _normalize_text(self, text):
        result = text.lower()
        result = RE_PUNC.sub(' ', result)
        result = RE_ART.sub(' ', result)
        result = ' '.join(result.split())

        return result
    
    def _bleu(self, ref_response, hyp_response, n=4):
        ref_tokens = normalize(ref_response).split()
        hyp_tokens = normalize(hyp_response).split()

        weights = [1.0/n] * n
        #smoothie = SmoothingFunction().method4
        
        #score = sentence_bleu([ref_tokens], hyp_tokens, weights, smoothing_function=smoothie)
        score = sentence_bleu([ref_tokens], hyp_tokens, weights)

        return score

    def _meteor(self, ref_response, hyp_response):
        score = single_meteor_score(ref_response, hyp_response, normalize)
        print('score:{}, ref_response:{}, hyp_response:{}'.format(score, ref_response, hyp_response))
        input()

        return score

    def _rouge(self, ref_response, hyp_response, mode='l'):
        ref_response = normalize(ref_response)
        hyp_response = normalize(hyp_response)

        rouge = Rouge()

        if mode == 'l':
            score = rouge.get_scores(hyp_response, ref_response)[0]['rouge-l']['f']
        elif mode == 1:
            score = rouge.get_scores(hyp_response, ref_response)[0]['rouge-1']['f']
        elif mode == 2:
            score = rouge.get_scores(hyp_response, ref_response)[0]['rouge-2']['f']
        else:
            raise ValueError("unsupported mode: %s" % mode)

        return score

                    
    def update(self, output):
        hyp_obj, ref_obj = output

        if ref_obj is not None:
            if hyp_obj is not None:
                self._detection_tp += 1
                '''
                self._selection_mrr5 += self._reciprocal_rank(ref_obj, hyp_obj, 5)
                self._selection_r1 += self._recall_at_k(ref_obj, hyp_obj, 1)
                self._selection_r5 += self._recall_at_k(ref_obj, hyp_obj, 5)
                '''

                self._generation_bleu1 += self._bleu(ref_obj, hyp_obj, 1)
                self._generation_bleu2 += self._bleu(ref_obj, hyp_obj, 2)
                self._generation_bleu3 += self._bleu(ref_obj, hyp_obj, 3)
                self._generation_bleu4 += self._bleu(ref_obj, hyp_obj, 4)                
                self._generation_meteor += self._meteor(ref_obj, hyp_obj)
                self._generation_rouge_l += self._rouge(ref_obj, hyp_obj, 'l')
                self._generation_rouge_1 += self._rouge(ref_obj, hyp_obj, 1)
                self._generation_rouge_2 += self._rouge(ref_obj, hyp_obj, 2)                                                             
            else:
                self._detection_fn += 1
        else:
            if hyp_obj is not None:
                self._detection_fp += 1
            else:
                self._detection_tn += 1

    def _compute(self, score_sum):        
        if self._detection_tp + self._detection_fp > 0.0:
            score_p = score_sum/(self._detection_tp + self._detection_fp)
        else:
            score_p = 0.0

        if self._detection_tp + self._detection_fn > 0.0:
            score_r = score_sum/(self._detection_tp + self._detection_fn)
        else:
            score_r = 0.0

        if score_p + score_r > 0.0:
            score_f = 2*score_p*score_r/(score_p+score_r)
        else:
            score_f = 0.0

        return (score_p, score_r, score_f)
    
    def name(self):
        return "PairwiseMetric"

    def compute(self):
        '''
        detection_p, detection_r, detection_f = self._compute(self._detection_tp)
        
        selection_mrr5_p, selection_mrr5_r, selection_mrr5_f = self._compute(self._selection_mrr5)
        selection_r1_p, selection_r1_r, selection_r1_f = self._compute(self._selection_r1)
        selection_r5_p, selection_r5_r, selection_r5_f = self._compute(self._selection_r5)
        '''

        generation_bleu1_p, generation_bleu1_r, generation_bleu1_f = self._compute(self._generation_bleu1)
        generation_bleu2_p, generation_bleu2_r, generation_bleu2_f = self._compute(self._generation_bleu2)
        generation_bleu3_p, generation_bleu3_r, generation_bleu3_f = self._compute(self._generation_bleu3)
        generation_bleu4_p, generation_bleu4_r, generation_bleu4_f = self._compute(self._generation_bleu4)
        generation_meteor_p, generation_meteor_r, generation_meteor_f = self._compute(self._generation_meteor)
        generation_rouge_l_p, generation_rouge_l_r, generation_rouge_l_f = self._compute(self._generation_rouge_l)
        generation_rouge_1_p, generation_rouge_1_r, generation_rouge_1_f = self._compute(self._generation_rouge_1)
        generation_rouge_2_p, generation_rouge_2_r, generation_rouge_2_f = self._compute(self._generation_rouge_2)
        
        ave_blue1_4 = (generation_bleu1_f + generation_bleu2_f + generation_bleu3_f + generation_bleu4_f)/4

        scores = {                                    
            'bleu-ave': ave_blue1_4,
            'bleu-1': generation_bleu1_f,
            'bleu-2': generation_bleu2_f,
            'bleu-3': generation_bleu3_f,
            'bleu-4': generation_bleu4_f,            
            'meteor': generation_meteor_f,
            'rouge_1': generation_rouge_1_f,
            'rouge_2': generation_rouge_2_f,
            'rouge_l': generation_rouge_l_f
        }

        return scores

class ReadinData4Direct(object):
    def __init__(self, evalfile, evalitem):
        #path = os.path.abspath('./')
        self.evalitem = evalitem
            
        if evalitem.lower() not in ['all', 'qanre','qa',  'qa-re', 'topic', 'qa-q', 'qt', 'qp']: #['all', 'QAnRe','QA',  'QA-re', 'Topic', 'QA-q', 'QT', 'QP']:
            raise ValueError('Wrong evaluation item name: %s' % (evalitem))

        #fn = os.path.join(path, evalfile)
        fn = evalfile
        with open(fn, 'r') as f:
            self.fn = json.load(f)

    def __iter__(self):
        if self.evalitem.lower() == 'all':
            for oneturn in self.fn:
                #print(oneturn)
                yield(normalize(oneturn['question_gen']), normalize(oneturn['question']), [(oneturn['answer_gen'], oneturn['answer']), (oneturn['aspn_gen'], oneturn['aspn']), (oneturn['gspn_gen'], oneturn['gspn'])])
        elif self.evalitem.lower() == 'qa': #QA
            print("설명: 6-teacher-predict를, 사람이 구축한 교사질문 5-teacher-target와 비교하는 것으로, feedback부분 포함한 비교임.")
            for oneturn in self.fn:
                if oneturn['aspn'] != 'type qa':
                    continue
                yield(normalize(oneturn['question_gen']), normalize(oneturn['question']), [(oneturn['answer_gen'], oneturn['answer']), (oneturn['aspn_gen'], oneturn['aspn']), (oneturn['gspn_gen'], oneturn['gspn'])])
        elif self.evalitem.lower() == 'qanre':  #QAnRe
            for oneturn in self.fn:
                if oneturn['aspn'] != 'type qa' and oneturn['aspn'] !='type qa-re':
                    continue
                yield(normalize(oneturn['question_gen']), normalize(oneturn['question']), [(oneturn['answer_gen'], oneturn['answer']), (oneturn['aspn_gen'], oneturn['aspn']), (oneturn['gspn_gen'], oneturn['gspn'])])
        elif self.evalitem.lower() == 'qa-re':  #'QA-re':
            for oneturn in self.fn:
                if oneturn['aspn'] !='type qa-re':
                    continue
                yield(normalize(oneturn['question_gen']), normalize(oneturn['question']), [(oneturn['answer_gen'], oneturn['answer']), (oneturn['aspn_gen'], oneturn['aspn']), (oneturn['gspn_gen'], oneturn['gspn'])])
        elif self.evalitem.lower() == 'topic':  #'Topic':
            for oneturn in self.fn:
                if oneturn['aspn'] !='type topic':
                    continue
                yield(normalize(oneturn['question_gen']), normalize(oneturn['question']), [(oneturn['answer_gen'], oneturn['answer']), (oneturn['aspn_gen'], oneturn['aspn'])])
        elif self.evalitem.lower() == 'qa-q': #QA-q
            print("설명: 6-teacher-predict의 질문부분을(피드백 제외한), 사람이 구축한 교사질문 5-teacher-target의 질문부분과 비교하는 것으로, feedback부분 제외한 비교임. ")
            for oneturn in self.fn:
                if oneturn['aspn'] != 'type qa':
                    continue
                yield(normalize(oneturn['question_gen']), normalize(oneturn['question']), None)
        elif self.evalitem.lower() == 'qt': #QT
            print("설명: 5-teacher-target의 질문부분을(피드백 제외한), reference인 연습문제 4-QA의 question과 비교함. 결과값은 데이터에 대한 것으로 모델과 무관.")
            for oneturn in self.fn:
                if oneturn['aspn'] != 'type qa':
                    continue
                yield(normalize(oneturn['question']), oneturn['gspn'], normalize(oneturn['question'])) #"4-QA": "<q> The three men could not agree on what the world's greatest wonder was because   _  . </q><a> they all had different ideas </a>",        
         
        elif self.evalitem.lower() == 'qp': #'QP'
            print("설명: 6-teacher-predict의 질문부분을(피드백 제외한), reference인 연습문제 4-QA의 question과 비교함. 결과값은 QT와 상대 비교하여, 연습문제의 question을 얼마나 변형하여 생성하였는지 확인.")
            for oneturn in self.fn:
                if oneturn['aspn'] != 'type qa':
                    continue
                yield(normalize(oneturn['resp_gen']), oneturn['gspn'], normalize(oneturn['resp']))


def main(argv):
    parser = argparse.ArgumentParser(description='Evaluate the system outputs.')

    parser.add_argument('-fn',dest='fn',action='store',metavar='JSON_FILE',required=True,
                        help='File containing output JSON')
    parser.add_argument('-evalitem', dest='evalitem', action='store', metavar='DATASET', choices=['all', 'qanre','qa', 'qa-re', 'topic', 'qa-q', 'qt', 'qp'], type = str.lower, required=True, help='The target to evaluate')    
    args = parser.parse_args()      
    

    #eval_targets =['all', 'qanre','qa', 'qa-re', 'topic', 'qa-q', 'qt', 'qp']
    eval_targets = [args.evalitem]
    metrics = [      
        EmbeddingMetric(dataroot='./'),
        PairwiseMetric(),   #from alexa-dstc9-1     ./baseline/utils/metrics.py
        UnigramMetric(metric="recall"), #from alexa-dstc9-1 ./baseline/scripts/scores.py
        UnigramMetric(metric="precision"),
        NGramDiversity(n=1),
        NGramDiversity(n=2),
        NGramDiversity(n=3),
        NGramDiversity(n=4),
        CorpusNGramDiversity(n=1),
        CorpusNGramDiversity(n=2),
        CorpusNGramDiversity(n=3),
        CorpusNGramDiversity(n=4)
    ]
    
    directeval = DIRECTEval()
    all_results = []

    for idx, evalitem in enumerate(eval_targets):
        bspn_acc=0
        aspn_acc=0
        bspn_num=0
        gspn_exact=0
        gspn_fuzzy=0
        gspn_num = 0

        data = ReadinData4Direct(evalfile=args.fn, evalitem=evalitem)
        
        (ubarbleu, sentbleu) = directeval.bleu_metric(data)    
        (bspn_acc, aspn_acc, bspn_num, gspn_exact, gspn_fuzzy, gspn_num) = directeval.acc_metrics(data)
        
        print('\ttutor_resp_bleu:{}'.format( int(ubarbleu*10000)/10000)) #bspn_num, 
        #print('hghdebug 0 ubarbleu:{},  sentbleu:{}\n\t{}, {}, {}, {}'.format(ubarbleu, sentbleu, bspn_acc, aspn_acc, gspn_exact, gspn_fuzzy))
        #input('bleu')
        
       
        turn_num = 0
        for (pred, ref, info) in data: 
            if ref == "":
                continue
            turn_num += 1

            if evalitem == 'qt' or evalitem == 'qp': #QT, QP
                print("QT 설명: resp(teacher-target)의 질문부분을(피드백 제외 못한), reference인 연습문제 4-QA의 question과 비교함. 결과값은 데이터에 대한 것으로 모델과 무관.")
                
                if '<sos_q> ' in ref:   #QT, QP
                    ref = ref[ref.find('<sos_q> ')+8:]
                if ' <eos_q>' in ref:
                    ref = ref[:ref.find(' <eos_q>')]
            
            re.sub("\s\s+", " ", pred)
            re.sub("\s\s+", " ", ref)
            pred = pred.strip(' \t\n\r')
            ref = ref.strip(' \t\n\r')
            #print('5.ref:{}\npred:{}'.format(ref, pred))
            #input('press enter')

            for metric in metrics:
                metric.update((pred, ref))
        
        eval_result={}
        #print('turn num in total:{}'.format(turn_num))
        eval_result['Evaluation target'] = evalitem
        eval_result['Total turn num'] = turn_num
        eval_result['UbarMetric'] = {'bspn_num':bspn_num, 'bspn_acc':bspn_acc, 'aspn_acc':aspn_acc,'gspn_num': gspn_num, 'gspn_exact':gspn_exact,'gspn_fuzzy':gspn_fuzzy,'Ubar-bleu':ubarbleu,'Sent-bleu':sentbleu}
        
        for metric in metrics:
            name = metric.name()
            score = metric.compute()        
            eval_result[name] = score
     
        all_results.append(eval_result)
    

    
    outputfile = args.fn 

    if 'evalitem' not in args: 
        outputfile = outputfile.replace(".json", ".scores.json")
    else: 
        outputfile = outputfile.replace(".json", "."+args.evalitem+".json")

    with open(outputfile, 'w') as out:
        json.dump(all_results, out, indent=2)
    #print('Output file: ', outputfile)
    
# python hgheval4direct.py [-evalitem all] -fn logs_test/output_epoch65_6F1T_train.json
# python hghscores.py -evalitem QAnRe -fn logs_test/output_epoch65_6F1T_train.json 
# python hghscores.py -evalitem QA -fn logs_test/output_epoch65_6F1T_train.json
# python hghscores.py -evalitem QA-re -fn logs_test/output_epoch65_6F1T_train.json
# python hghscores.py -evalitem Topic -fn logs_test/output_epoch65_6F1T_train.json
if __name__ =="__main__":
    main(sys.argv)        
